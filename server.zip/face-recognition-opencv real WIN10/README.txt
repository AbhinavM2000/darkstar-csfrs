Run main.py after all required python modules are installed


username is :abhinavm17
password is:letmein


Default IP is set in the recognize_faces_video.py change as necessary
(Use IP webcam on android to test)

This folder should be in desktop

client side is on csfrs.eu.org, login with :testtest as uname and pw, (you can go back by clicking on the 'CSFRS' text)

3-4 images are required to recognize, upload on client side and package zip, then search target(main.py should be running beforehand)

A video demonstration would be more apt, im working on it.