import urllib.request
import zipfile
import config
import re
def zipp():
    line=[]
    data = urllib.request.urlopen("https://csfrs.eu.org/send/trigger.txt")
    for line in data:
        if not line:
            continue	
        else:
            line = line.decode('ISO-8859-1')
            if line == 'https://csfrs.eu.org/upload/id_01.zip':
                config.cursid='id_01'
                urllib.request.urlretrieve(line, config.pdzip1)            
                zfile = zipfile.ZipFile(config.pdzip1)
                zfile.extractall(config.pdfol1)
                zip_ref = zipfile.ZipFile(config.pdzip1, 'r')
                zip_ref.extractall(config.pdfol1)
                zip_ref.close()
            
            if line == 'https://csfrs.eu.org/upload/id_02.zip':
                config.cursid='id_02'
                urllib.request.urlretrieve(line, config.pdzip2)           
                zfile = zipfile.ZipFile(config.pdzip2)
                zfile.extractall(config.pdfol2)
                zip_ref = zipfile.ZipFile(config.pdzip2, 'r')
                zip_ref.extractall(config.pdfol2)
                zip_ref.close()
            
            if line == 'https://csfrs.eu.org/upload/id_03.zip':
                config.cursid='id_03'
                urllib.request.urlretrieve(line, config.pdzip3)            
                zfile = zipfile.ZipFile(config.pdzip3)
                zfile.extractall(config.pdfol3)
                zip_ref = zipfile.ZipFile(config.pdzip3, 'r')
                zip_ref.extractall(config.pdfol3)
                zip_ref.close()
            
            


