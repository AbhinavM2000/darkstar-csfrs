import urllib.request, urllib.error, urllib.parse
import urllib.request, urllib.parse, urllib.error
import base64
import json
import requests
import urllib
import base64
import json
import argparse
import webbrowser
from time import sleep





def messyfn():
	import ftplib
	session = ftplib.FTP('ftp.csfrs.eu.org','ftpcsfrs@csfrs.eu.org','koppkoppkopp1A')
	file = open('test1.jpg','rb')                  # file to send
	session.storbinary('STOR temp.png', file)     # send the file
	sleep(1.0)
	file.close()                                    # close file and FTP
	session.quit()
	sleep(1.0)
	f = open("test1.jpg", "rb") # open our image file as read only in binary mode
	image_data = f.read()              # read in our image file
	b64_image = base64.standard_b64encode(image_data)
                    
	client_id = "30cb719182fdc99" # put your client ID here
	headers = {'Authorization': 'Client-ID ' + client_id}
	data = {'image': b64_image, 'title': 'test'} # create a dictionary.
	request = urllib.request.Request(url="https://api.imgur.com/3/upload.json",data=urllib.parse.urlencode(data).encode("utf-8"),headers=headers)
	response = urllib.request.urlopen(request).read()
	parse = json.loads(response)
	dataimg = parse['data']['link']
	print(dataimg)
	r = requests.get("https://csfrs.eu.org/send/imagedisp.php?link="+dataimg)	
	r = requests.get("https://csfrs.eu.org/send/statuschanger.php?var=3")