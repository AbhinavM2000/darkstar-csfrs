<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: https://csfrs.eu.org/login.php");
    exit;
}
?>




<!DOCTYPE html>
<script>
function zoomOutMobile() {
  var viewport = document.querySelector('meta[name="viewport"]');

  if ( viewport ) {
    viewport.content = "initial-scale=0.1";
    viewport.content = "width=720";
  }
}




</script>

<html lang="en" >

<head>
  <meta name="viewport" content="width=720, initial-scale=1">
  <script>
  if( screen.width<1280 ){ zoomOutMobile(); }</script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">  
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  
  
      <link rel="stylesheet" href="css/style.css">

  
</head>
<script type="text/javascript">
        function zoom() {
            document.body.style.zoom = "150%" 
        }
</script>

<body onload="zoom()">
 <canvas id='matrix'>
      
      
    
      
      
      
      
  </canvas>
  
  
  



<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
    
    
    
</script>

    
<style>.modal-body {
    max-height: calc(100vh - 210px);
    overflow-y: auto;
}</style>




<div class="container">

  
  <!-- Button to Open the Modal -->
 
    


  <!-- The Modal -->
  <div class="modal fade" id="myModal" data-backdrop="false" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered ">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header" >
          <h4 class="modal-title"  style="margin: 0 auto;" ><a href="https://csfrs.eu.org/dash" style="color: #000000; font-size: 21px; font-family: Courier New; text-decoration:none; font-weight:bold"" target="_self">CSFRS 1.0</a> </h4>
         
        </div>
        
        <!-- Modal body -->
        <div class="modal-body" style="text-align: center overflow-y: autposo;">
       
       <div class="w3-container">     
           <a data-toggle="modal" class="btn w3-block w3-black w3-large" href="https://csfrs.eu.org/upload" data-target="#myModal2">UPLOAD TARGET DATA</a>
 
 
<div class="modal-dialog modal-lg hide fade " id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"  aria-hidden="true" style="width:90%">
  <div class="modal-header">
  
     <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
    <h3 id="myModalLabel">Modal header</h3>
 
  <div class="modal-body">
  </div>
</div>
 </div>

<script>


</script>



            <br><br>
            
            
            
            
             <a href="https://csfrs.eu.org/send/stop.php" class="btn w3-block w3-black w3-large">STOP CURRENT OPERATION</a>
             
             <br><br>
            
            
            
            
             <a href="https://csfrs.eu.org/send/send.html" class="btn w3-block w3-black w3-large">SEARCH TARGET</a>
             
              <br><br>
            
             
             <a href="https://csfrs.eu.org/send/statusdisp.php" class="btn w3-block w3-black w3-large">STATUS</a>
             
             <br><br>
             
             <a href="https://csfrs.eu.org/send/imagelinks.php" class="btn w3-block w3-black w3-large">RESULTS</a>
             <br><br>

              <a href="https://csfrs.eu.org/send/log.php" class="btn w3-block w3-black w3-large">LOG</a>
             

              
             
             
              
             
             
              <br><br>
            
             <a href="https://csfrs.eu.org/logout.php" style="text-decoration:none" class=" w3-btn w3-block w3-black w3-round-large"><b>LOGOUT</b></a>
             
</div> 
            
            
            
          
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
         
        </div>
        
      </div>
    </div>
  </div>
  
</div>


<script>


$('a.btn').on('click', function(e) {
    e.preventDefault();
    var url = $(this).attr('href');
    $(".modal-body").html('<iframe width="100%" height="100%" frameborder="0" scrolling="yes" allowtransparency="true" src="'+url+'"></iframe>');

   
    
});







</script>





<svg class='hide' xmlns="http://www.w3.org/2000/svg">
	  <defs>
		    <filter id='blur-horizontal'>
	<feGaussianBlur stdDeviation='3,0' />
    		</filter>
    		<filter id='blur-vertical'>
			      <feGaussianBlur stdDeviation='0,6' />
		    </filter>
	  </defs>
</svg>
  
  

    <script  src="js/index.js"></script>




</body>

</html>
