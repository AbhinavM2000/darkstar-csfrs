<?php

if(isset($_FILES["file"]["error"])){
    if($_FILES["file"]["error"] > 0){
        echo "Error: " . $_FILES["file"]["error"] . "<br>";
    } else{
        $allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png", "doc" => "application/msword", "docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "xls" => "application/vnd.ms-excel", "xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "pdf" => "application/pdf", "txt" => "text/plain");
        $filename = $_FILES["file"]["name"];
        $filetype = $_FILES["file"]["type"];
        $filesize = $_FILES["file"]["size"];

        // Verify file extension
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        if(!array_key_exists($ext, $allowed)) die("Error: This file is not an accepted file type.</br></br>");

        // Verify file size - 10MB maximum
        $maxsize = 200000 * 60;
        if($filesize > $maxsize) die("Error: File size is larger than the allowed 10MB limit.</br></br>");

        // Verify MYME type of the file
        if(in_array($filetype, $allowed)){
            // Check whether file exists before uploading it
            if(file_exists("general/" . $_FILES["file"]["name"])){
                echo $_FILES["file"]["name"] . " already exists. Go back and choose another file or rename the original.</br></br>";
            } else{

// My snippet START 
    if(isset($_POST['folder'])){

        if($_POST['folder'] == 'this'){

        // move_uploaded_file to said folder

        $uploaddir = '/home/somethin/public_html/upload/id_01/';
        $uploadfile = $uploaddir . basename($_FILES['file']['name']);

        move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile);
        header("Location:https://csfrs.eu.org/upload/");           

        }

        if($_POST['folder'] == 'BBB'){

        // move_uploaded_file to said folder

        $uploaddir = '/home/somethin/public_html/upload/id_02/';
        $uploadfile = $uploaddir . basename($_FILES['file']['name']);

        move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile);
         header("Location:https://csfrs.eu.org/upload/");           

        }

 if($_POST['folder'] == 'CCC'){
     
        $uploaddir = '/home/somethin/public_html/upload/id_03/';
        $uploadfile = $uploaddir . basename($_FILES['file']['name']);

        move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile);
        header("Location:https://csfrs.eu.org/upload/");           

        }



 if($_POST['folder'] == 'DDD'){
     

        $uploaddir = '/home/somethin/public_html/upload/id_04/';
        $uploadfile = $uploaddir . basename($_FILES['file']['name']);

        move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile);
        header("Location:https://csfrs.eu.org/upload/");           

        }



 if($_POST['folder'] == 'EEE'){
     

        $uploaddir = '/home/somethin/public_html/upload/id_05/';
        $uploadfile = $uploaddir . basename($_FILES['file']['name']);

        move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile);
         header("Location:https://csfrs.eu.org/upload/");           

        }



        // ... do the same for the others below


    }

// My snippet END

            }
        }
        else{
            echo "Error: There was a problem uploading the file - please try again."; 
        }
    }
} else{
    echo "Error: Invalid parameters - something is very wrong with this upload.";
}
?>