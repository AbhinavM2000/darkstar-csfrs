
<?php


$var=$_GET["var"];

if($var =3)
    $fp = fopen('statusdisp.php', 'w');
    fwrite($fp, '--Target found, check RESULTS tab ');
    fclose($fp);
    $fp = fopen('trigger.txt', 'w');
    fwrite($fp, "0");
    fclose($fp);
$fp = fopen('status.txt', 'w');
fwrite($fp, $var);
fclose($fp);


?>