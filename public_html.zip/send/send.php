<?php
 
  $var=$_POST['select2'];




  $fp = fopen('trigger.txt', 'w');
fwrite($fp, "https://csfrs.eu.org/upload/$var.zip");
fclose($fp);



 $fp = fopen('status.txt', 'w');
fwrite($fp, "1");
fclose($fp);

$fp = fopen('status2.txt', 'w');
fwrite($fp, "2");
fclose($fp);

  $fp = fopen('statusdisp.php', 'w');
fwrite($fp, "-Currently searching for target $var");
fclose($fp);
    

echo "Command has been passed to the server, image processing make take some time, you can check the status tab for updates.";






 ?>