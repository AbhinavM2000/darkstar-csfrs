<?php

$fp = fopen('status.txt', 'w');
fwrite($fp, "2");
fclose($fp);

$fp = fopen('trigger.txt', 'w');
fwrite($fp, "0");
fclose($fp);

$fp = fopen('status2.txt', 'w');
fwrite($fp, "0");
fclose($fp);

$fp = fopen('statusdisp.php', 'a');
fwrite($fp, "\n-Search operation stopped");
fclose($fp);

echo  "Current search will be terminated shortly"

?>