<style>
    
body {
    color: #333333;
    font-family:'Helvetica', arial;
    height:1500px;
    margin-top: 0px;
}
.wrap {
    padding: 40px;
    text-align: center;
}
hr {
    clear: both;
    margin-top: 10px;
    margin-bottom: 40px;
    border: 0;
    border-top: 1px solid #aaaaaa;
}
h1 {
    font-size: 30px;
    margin-bottom: 0px;
    margin-top: 0px;
}
p {
    margin-top: 0px;
    margin-bottom: 10px;
}

label {
  display: flex;
  flex-direction: row;
  justify-content: auto;
  text-align: auto;
  width: 500px;
  line-height: 25px;
  margin-bottom: 0px;
}

input {
  height: auto;
  flex: 0 0 200px;
  margin-left: 20px;
}
.btn {
    background: #428bca;
    border: #357ebd solid 1px;
    border-radius: 3px;
    color: #fff;
    display: inline-block;
    font-size: 14px;
    padding: 8px 15px;
    text-decoration: none;
    text-align: auto;
    min-width: 60px;
    position: relative;
    transition: color .1s ease;
}
.btn:hover {
    background: #357ebd;
}
.btn.btn-big {
    font-size: 18px;
    padding: 15px 20px;
    min-width: 100px;
}
.btn-close {
    color: #aaaaaa;
    font-size: 30px;
    text-decoration: none;
    position: absolute;
    right: 5px;
    top: 0;
}
.btn-close:hover {
    color: #919191;
}
.modal:target:before {
    display: none;
}
.modal:before {
    content:"";
    display: block;
    background: rgba(0, 0, 0, 0.6);
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 10;
}
.modal .modal-dialog {
    background: #fefefe;
    border: #333333 solid 1px;
    border-radius: 5px;
    margin-left: -180;
    position: fixed;
    left: 50%;
    z-index: 11;
    width: 360px;
    -webkit-transform: translate(0, 0);
    -ms-transform: translate(0, 0);
    transform: translate(0, 0);
    -webkit-transition: -webkit-transform 0.3s ease-out;
    -moz-transition: -moz-transform 0.3s ease-out;
    -o-transition: -o-transform 0.3s ease-out;
    transition: transform 0.3s ease-out;
    top: 20%;
}
.modal:target .modal-dialog {
    top: -100%;
    -webkit-transform: translate(0, -500%);
    -ms-transform: translate(0, -500%);
    transform: translate(0, -500%);
}
.modal-body {
    padding: 0px;
}
.modal-header, .modal-footer {
    padding: 0px 20px;
}
.modal-header {
    border-bottom: #eeeeee solid 1px;
}
.body{ font: 14px sans-serif; }
.wrapper{ width: 400px; padding: 10px; }
.modal-header h2 {
    font-size: 20px;
}
.modal-footer {
    border-top: #eeeeee solid 1px;
    text-align: right;
}
    
    
</style>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>CSFRS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<body style="background-color:powderblue;">


<div class="container">

  <!-- Trigger the modal with a button -->


  <!-- Modal -->
  <div class="modal show" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" onclick = "$('.modal').removeClass('show').addClass('fade');Redirect();">&times;</button>
          <h4 class="modal-title">Register an account</h4>
        </div>
        <div class="modal-body">
            <div class="wrapper">
        <p>Contact the administrator via the email below to<br> register an account.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                <label>info@csfrs.eu.org</label>
            </div>    
            
            <p></p>
            <div class="form-group">
                
            </div>
            <p><br>Already have an account? <a href="login.php">Login here</a>.</p>
        </form>
  

            
         
         
         
         
         
         
         
         
         
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" onclick = "$('.modal').removeClass('show').addClass('fade');Redirect();">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

</body>
<script>
    
    function Redirect() 
    {  
        window.location="https://csfrs.eu.org/"; 
        
    } 
   
    
</script>
</html>







