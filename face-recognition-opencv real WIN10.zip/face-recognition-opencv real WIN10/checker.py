import time
from recognize_faces_video import frnn
from encode_faces import fren
from urllib.request import urlopen
from zipper import zipp
import config
flag=0
rc=0
fuse=0
def chklink():
    global flag,rc,fuse
    data = urlopen("https://mystupidblog.site/bs/DARKSTAR/send/trigger.txt").read()
    data2 = urlopen("https://mystupidblog.site/bs/DARKSTAR/send/status2.txt").read()
    if data2 == b'2':
            rc+=1
            if rc==1:
                print("[INFO] Run command received for first time")
    if data == b'0' or data2 == b'0':
            flag=0
            rc=0
            fuse=0
            print("[INFO] Web stop detected, remaining idle")
    if rc>1:
        print("[INFO] Already running, skipping check")
    while rc==1 and fuse==0:
        if data != b'0' and rc == 1:
            flag=1
            #do all the  zipper.py, encode.py and execute frnn()
            print("[INFO] Fetching dataset from webserver")
            zipp()
            print("[INFO] Encoding facial data...")
            fren()
            print("[INFO] Running facial recognition on source")
            frnn()
            fuse=1
        
        
    time.sleep(config.sysrefresh)
    
def checker():
    #flag 2 means link is available so search happening
    while 1:
        chklink()
    
    
 