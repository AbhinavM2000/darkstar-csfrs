import datetime
import sys
import os
import time
import msvcrt
from getpass import getpass
import config
from checker import checker
idchk=-1
uname=[]
passwor=[]
import sys


        
def chkpass():
    global idchk,passwor,uname
    passwor=getpass()

    if passwor==config.passw:
        idchk+=1
def login(): 
    global idchk,passwor,uname
    print('\nEnter username ')
    un=str(input())
    if un == config.uname:
        idchk+=1
    print('\nEnter password ')
    chkpass()

    if idchk!=1 :
        print ('Usernname and password wrong\n')
        time.sleep(3)
        os.system('cls')
    if idchk==1: 
        print("\nLogged in as ")
        print(config.uname) 
        print("\n")

while idchk!=1:
    login()

print("[INFO] Set config variables\n")        
print("Enter x to use defaults\n")
inp=str(input())
if inp!='x':
    print("--Facial recog. algorithm :")
    config.falg=str(input())
    print("\n--Dataset .zip path:")
    config.pdzip=str(input())
    print("\n--Dataset folder path:")
    config.pdfol=str(input())
    print("\n--System refresh time in sec :")
    config.sysrefresh=int(input())
print("\n--Set input stream IP:")
config.instreamip=str(input())

print("\nConfirm password to start server\n")
chkpass()
if passwor == config.passw :
    now = datetime.datetime.now() 
    print("\n[INFO] Starting Server" + ' ' + now.strftime("%Y-%m-%d %H:%M:%S") + " ")
    checker()
else:
    sys.exit("Operation Aborted - Wrong password")












 

